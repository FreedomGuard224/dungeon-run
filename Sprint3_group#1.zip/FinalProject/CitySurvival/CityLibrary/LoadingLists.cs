﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace CityLibrary
{
    public class LoadingLists
    {
        //
        //
        //
        //  Loading in all of the potion, weapon, and thug objects
        //  It's just convenient to put it here rather than elsewhere.
        public static List<Weapon> weaponList = new List<Weapon>();
        public static List<Potion> potionList = new List<Potion>();
        public static List<Thug> Mobs = new List<Thug>();



        public static void LoadAll()
        {
            
            //hard coded because we ran out of time.

            string name;
            string description;
            int damage;

            // Weapons: baseball bat, pipe, chain, knife, fists

            name = "baseball bat";
            description = "Apparently there was a time when this was only for sports.";
            damage = 10;

            weaponList.Add(new Weapon(name, description, damage));

            name = "fists";
            description = "Those things at the end of your arms.";
            damage = 3;

            weaponList.Add(new Weapon(name, description, damage));


            name = "pipe";
            description = "Old plumbing material, rusty but strong.";
            damage = 12;

            weaponList.Add(new Weapon(name, description, damage));


            name = "chain";
            description = "A length of loops absconded from a swingset.";
            damage = 12;

            weaponList.Add(new Weapon(name, description, damage));


            name = "knife";
            description = "An edged weapon for the privileged.";
            damage = 8;
            weaponList.Add(new Weapon(name, description, damage));


            name = "brass knuckles";
            description = "Usually given as a sign of favor from a gang boss.";
            damage = 7;
            weaponList.Add(new Weapon(name, description, damage));



            // health boost items
            string pname;
            string pdescription;
            int boost;

            pname = "bottled water";
            pdescription = "It's pretty much the only water safe to drink";
            boost = 5;
            potionList.Add(new Potion(pname, pdescription, boost));

            pname = "canned food";
            pdescription = "Is it beans?  Canned bone-in salmon?  Luck of the draw.";
            boost = 10;
            potionList.Add(new Potion(pname, pdescription, boost));



            // Thugs
            // baseball thug, brass knuckles thug, knife thug, fists thug
            // gangtype, maxhp, hp, weapon
            string gangtype;
            int maxhp;
            int hp;
            Weapon weapon;


            // Level 1, Fists thug.
            gangtype = "Unarmed thug";
            maxhp = 25;
            hp = maxhp;
            weapon = weaponList[1];
         
            Mobs.Add(new Thug(gangtype, maxhp, hp, weapon));

            // Level 2, brass knuckles thug.
            gangtype = "Knuckles thug";
            maxhp = 30;
            hp = maxhp;
            weapon = weaponList[5];

            Mobs.Add(new Thug(gangtype, maxhp, hp, weapon));

            // Level 3, knife thug.
            gangtype = "Knife guy";
            maxhp = 30;
            hp = maxhp;
            weapon = weaponList[4];

            Mobs.Add(new Thug(gangtype, maxhp, hp, weapon));

            // Level 4, bat thug.
            gangtype = "Bat wielder";
            maxhp = 35;
            hp = maxhp;
            weapon = weaponList[1];

            Mobs.Add(new Thug(gangtype, maxhp, hp, weapon));

            // Level 5, pipe thug.
            gangtype = "Pipe baddie";
            maxhp = 40;
            hp = maxhp;
            weapon = weaponList[2];

            Mobs.Add(new Thug(gangtype, maxhp, hp, weapon));

            // Level boss, pipe thug.
            gangtype = "boss";
            maxhp = 40;
            hp = maxhp;
            weapon = weaponList[2];

            Mobs.Add(new Thug(gangtype, maxhp, hp, weapon));

        }
    }
}
