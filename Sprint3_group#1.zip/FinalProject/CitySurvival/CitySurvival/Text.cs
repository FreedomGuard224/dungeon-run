﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CityLibrary;


namespace CitySurvival
{
    public class Text
    {
        //
        // Utility  or battle functions for player, should be available for all rooms. 
        //
        //
        public static void LookInventory(Player player)
        {
            Console.Write("Here is your inventory:  ");
            for (int i = 0; i<player.Inventory.Count; i++)
            {
                if (i == player.Inventory.Count - 1)
                {
                    Console.WriteLine($"{player.Inventory[i]}\n");
                }
                else
                {
                    Console.Write($"{player.Inventory[i]}, ");
                }
            }

            Console.WriteLine($"\nYou have {player.Cigarettes} cigarettes.");

            int countWater = 0;
            int countCans = 0;

            Console.WriteLine("\nHere are your healing items: ");
            foreach (Potion booster in player.Potions)
            {
                if (booster.Name == "bottled water")
                {
                    countWater += 1;
                }
                else
                {
                    countCans += 1;
                }
            }

            Console.WriteLine($"You have {countWater} bottles of water");
            Console.WriteLine($"You have {countCans} cans of food");

            Console.WriteLine("\nHere are your weapons: ");
            foreach (Weapon fight in player.Weapons)
            {
                Console.WriteLine($"{fight.Name}:  {fight.Description}");
            }
        }
        
        public static void Help()
        {
            Console.WriteLine("\n Help Text -- ");
            Console.WriteLine("The listed options for a given room are not the only actions you can take.  You can \'look\' and \'search\' all important" +
                "items or areas.  Capitalization does not matter.  ");
            Console.WriteLine("Some of your items are helpful, the others are just for fun.");
            // This is all I could think of for now, adding more help text when issues pop up.
        }

        //
        //  This is used as test dialogue for any item that a player might want to pick up, but isn't pickupable.
        public static void DontWant()
        {
            var random = new Random();
            int message = random.Next(10);

            switch (message)
            {
                case 0:
                    Console.WriteLine("\nI don't see why you would want that.");
                    break;
                case 1:
                    Console.WriteLine("\nBut why?");
                    break;
                case 2:
                    Console.WriteLine("\nThat's not useful to you now.");
                    break;
                case 3:
                    Console.WriteLine("\nCan't you just leave it alone?");
                    break;
                case 4:
                    Console.WriteLine("\nNah, you don't want that.");
                    break;
                case 5:
                    Console.WriteLine("\nIt's not important.");
                    break;
                case 6:
                    Console.WriteLine("\nIt doesn't look appealing");
                    break;
                case 7:
                    Console.WriteLine("\nNo, not right now.  Or ever, really.");
                    break;
                case 8:
                    Console.WriteLine("\nThis item is only here to look good.");
                    break;
                case 9:
                    Console.WriteLine("\nYou don't need every item you see.");
                    break;
                default:
                    Console.WriteLine("...Something has gone wrong with the code.  Check Text.DontWant().");
                    break;
            }


        }



        // Battle program for generic battles.
        public static Player BattleTime(Player player)
        {
            // put stuff here when you figure out how to do battles
            return player;
        }







        //
        //
        // Room specific text goes below here.
        //
        //




        //
        //
        // The bakery
        public static void BakeryLook()
        {
            Console.WriteLine("\nYou are in the remains of what was once an old bakery.  Against the south wall is a large pile of soft-ish rubbish, " +
                "mainly meant for sleeping.  To the west are a few cabinets, generally only containing things not worth stealing.  Exit doors fit " +
                "into the north and east walls.  In the northeast corner is a makeshift shower made from a few old hoses and coffee cans.  ");
        }
        public static Player Cabinets(Player player)
        {
            Console.WriteLine("You search through the cabinets only casually.  It wouldn't do to look too eager to search through other people's " +
                "belongings.  Most of the cabinets still have doors, and those that don't are generally empty of all but greasy rags or other detritus.");

            // temporary item until items have been worked out
            if (player.Inventory.Contains("hammer"))
            {
                Console.WriteLine("You search the cabinet that is more or less yours.  It's still got the old random junk in it.  No surprises.");
            }
            else
            {
                Console.WriteLine("One specific cabinet is more or less yours.  You've been putting random items in it so that the randos in here " +
                    "get used to the idea that it's yours.  Mainly you put in it random junk -- the arms of broken action figures, paperclips, broken " +
                    "pottery -- anything to suggest that you're some eclectic who likes things not worth owning.  You search through it, and find that " +
                    "one of the items actually is useful.");
                // insert item getting code here
                // player.Inventory.Add(hammer);
                return player;
            }
            return player;
        }
        public static void Showers()
        {
            Console.WriteLine("You're not terribly shy about showering in front of the guys in the bakery -- as a rule, nobody stares -- but it's nice " +
                "to have shower curtains anyway.  Actual curtains, that is, strung about with some old fishing line.  You push past the fabric and check " +
                "behind the jerry-rigged shower.  Aw great, they didn't fill up the water tanks.  Lovely.  Good thing you checked before taking off your" +
                "clothes. ");
        }

        public static void Rubbish()
        {
            Console.WriteLine("You search through the pile of rags and tattered furniture bits that are not currently covered by the sleeping or " +
                "resting.  As you expect, there's nothing you need.");
        }






        //
        //
        //  The bank Lobby

        public static void BankLobbyLook()
        {
            Console.WriteLine("This is the lobby of a long since defunct bank.  Careful examination of the walls would reveal the last remains" +
                "of the retirement savings adverts.  To the north is a door to an office.  Curving around the northeast corner of the lobby is a bank counter, " +
                "chipped and faded with age and bullets.  It leads to a vault in the back.  Before this counter is old velvet barrier remains, as well as " +
                "various rummage strewn about the floor.  There's a window to the south.  To the west is the door from which you came.");
        }
        public static void BLBattleText()
        {
            // This exists as room-specific flavortext for when battle starts.  It is does not the handle actual battles.
            Console.WriteLine("Battle flavor text for this room has not yet been written");
        }
        public static void LookBarrier()
        {
            Console.WriteLine("\nThe old velvet barrier that now lies rotting on the floor was apparently used to help people line up for service in the bank.  " +
                "So you were told.  You were too young to have a bank account when everything changed, so you're not sure.  It's hard to imagine people ever waiting " +
                "in a line these days, though.");
        }
        public static void TakeBarrier()
        {
            Console.WriteLine("\nAs you kneel to get closer to the velvet barriers, that's when you notice the smell.  Just in time to stop yourself from actually " +
                "touching the fabric, you see aged spots of greenish-grey mold decorating the back and underside of the rope.  You pull back your hand and " +
                "straighten, trying not to think about how nasty actually touching it would have been.");
        }
        public static void LookRummage()
        {
            Console.WriteLine("\nThere sure is a lot of garbage around this place.  It seems to be primarily old beer cans, dirty needles, and broken glass.  " +
                "In other words, it has nothing that you really want.  Well, if you had a gun, you could use all the discarded shell casings to make your own " +
                "bullets.");
        }
        public static void LookCounter()
        {
            Console.WriteLine("\nWell, it's a counter alright.  The gun-damaged wall behind it was apparently not the only thing used for target practice.  The " +
                "counter's outer sill is also shot up.  If you wanted to, you could pick out some lead from all the old bullets in it.  The one good thing about the " +
                "Mange taking control of all weaponry in this sector to fight outsiders is that these impulsive gun games are a lot less common.");
        }
        public static void LookBehindCounter()
        {
            Console.WriteLine("\nOh wow, it's really a mess back here.  Broken glass and discarded cans everywhere.  You'd figure that the Mange would have one of " +
                "their lackeys clean up a bit, if only so that they can have target practice again.");
        }
        public static void LookBehindCounter2()
        {
            Console.WriteLine("\tOh look, a pen.  You pick it up.  Never know when that might come in handy.");
        }
        public static void LookBankWindow()
        {
            Console.WriteLine("\nYou look out of the window, but there isn't much to see.  It's just a bare patch of sky visible over the wall pressed up against the " +
                "outside of the bank.  Nobody's really sure why the wall is there.  The window it blocks is broken, but nobody has bothered to graffiti this side of the " +
                "wall.  It's a good thing that this bank has skylights, or else nothing inside would be visible.");
        }
        public static void LookAdverts()
        {
            Console.WriteLine("\nYou look up at the advertisements on the wall.  Behind the plastic and grime are pictures of very happy-looking people posing.  " +
                "Their faces have long since been scribbled over with various marks and slogans, the largest of which says \"Rage the Mange\".  You're not " +
                "sure what that's supposed to mean. The images behind the counter seem to have been used for target practice, so their images are lost to time." +
                "\n\tThe largest and hardest to reach advert (and thus least defaced) is one of an elderly couple in a boat.  " +
                "The direct, wide angle of the picture makes it look like they're somehow flying their motorboat up out of the water.  You wish that you could fly " +
                "away from here, even if in a ridiculous apparatus.");
        }


        //
        //
        // The bank office
        public static void BankOfficeLook()
        {
            Console.WriteLine("The old office is messier than usual.  You know that people come in here from time to time, judging from all the old cigarette butts " +
                "on the floor.  There's a beat up old desk, and likewise a couple of much abused old office chairs.  A window to the west casts a smoky light across the " +
                "room.  The only exit is the way you came, to the south.");
        }
        public static void BOBattleText()
        {
            // This exists as room-specific flavortext for when battle starts.  It is does not the handle actual battles.
            Console.WriteLine("Battle flavor text for this room has not yet been written");
        }
        public static void LookOfficeWindow()
        {
            Console.WriteLine("You peek a little sideways out of the window.  You see a roving thug or two, but they aren't paying you any attention.  Even if they were, " +
                "it's not easy to see much through the dirty window.  Still, you are able to see the street, and primarily the hotel across it.  Not the best view.");
        }
        public static void LookDesk()
        {
            // Add a packet of cigarettes here when the inventory system is figured out. 
            Console.WriteLine("There isn't much in the desk, aside from a few papers.  You're not really sure why, but it looks like one of the thugs has kept some of " +
                "the bank's papers.  Most of them are yellowed with age, and you find it difficult to understand what they're supposed to mean.  The paper on top says " +
                "\"September Statement\" and then lists various things with monetary units on the side.  Huh, these must technically be artifacts in this day and " +
                "age.");
        }
        public static void TakePapers()
        {
            Console.WriteLine("Well, alright.  You take the odd papers out of the desk and stash them on your person.  Huh, there's something written on the back of " +
                "one of these papers.  It looks like a poem.");
        }
        public static void ReadPoem()
        {
            Console.WriteLine("You read the poem: ");
            Console.WriteLine("\n\tStreets stretch out to follow the wind");
            Console.WriteLine("\tThe wind flies on, passing them by");
            Console.WriteLine("\tStationary lines of tar imitate");
            Console.WriteLine("\tBut they will never reach a sky.");
            Console.WriteLine("\tI too march with these streets");
            Console.WriteLine("\tGun and I, we tell their same lie.");
            Console.WriteLine("\nWow, that was, uh...something else.");
        }
        public static void LookOfficeChair()
        {
            Console.WriteLine("\nThis chair used to be fancy.  Actually, it's still pretty fancy.  It smells of cigarette smoke, but the cushion's stuffing is only " +
                "poking out from the lower left side.  You sit in the chair for a bit to rest.  Yep, pretty comfy.");
        }
        public static void TakeStuffing()
        {
            // add cigarette here when inventory figured out. 
            Console.WriteLine("\nFor some reason, you decide to take out the stuffing.  What's this?  Oh, someone stashed a couple of cigarettes.  Nice.");
        }
        


        //
        //
        // The bank vault
        public static void BankVaultLook()
        {
            Console.WriteLine("The vault has long since been completely looted.  All of the deposit boxes are various degrees of open and empty, at least to the " +
                "casual glance.  It's too dark in here for you to do much in the way of looking.  The only exit is south.");
        }
        public static void VaultSearch()
        {
            Console.WriteLine("You search the vault for a while, but it's pretty annoying to do without a light source.  Particularly since there's some broken " +
                "glass on the bottom of the floor.  You search for a bit, but give up pretty quickly.");
        }
        public static void VaultSearchLight()
        {
            Console.WriteLine("You search the vault for a while.  It's a little easier with a flashlight, but there's literally deposit boxes left, right, and center, " +
                "from the floor to the ceiling.  You don't want to be here all day.  You search for a bit, then stop.");
        }
        public static void BankVaultLookLight()
        {
            Console.WriteLine("The vault has long since been completely looted.  All of the deposit boxes are various degrees of open and empty, at least to the " +
                "casual wave of your flashlight.  A metal...block...thing sits in the middle of the room.  It's apparently used to serve as a table, back when the " +
                "city was its old self.  You can barely remember those old days.  The only exit is south.");
        }

        // No battling in the vault.  Dealing with the darkness aspect of fighting is just too much for one semester project.
        //
        //public static void BVBattleText()
        //{
        //    // This exists as room-specific flavortext for when battle starts.  It is does not the handle actual battles.
        //    Console.WriteLine("Battle flavor text for this room has not yet been written");
        //}








        //
        //
        //  The Hotel Lobby and Stairwell.
        public static void HotelLobbyLook()
        {
            Console.WriteLine("\nYou enter the lobby of the hotel.  While generally the Mange allow for trading here, they also have a pretty tight control " +
                "on the hotel.  As evidenced by the two guys guarding the stairs to the west.  They won't stop other members from fighting you if they're " +
                "bored, but they also won't let you go up the stairs.  You can try, but two of the city's limited guns are in their arms.  To the north are " +
                "the grand double doors to the hotel's old ballroom.  As for the rest of the lobby, it's just dirty, smokestained carpet and a potted plant in the " +
                "far corner.  It smells like years of tobacco and stale farts.  You can leave out the door to the east.");
        }
		public static void LobbyBattleText()
        {
			// Note that for this room, there will only be one or two weak enemies.  The hotel is mostly neutral, so there should only be a small chance
			//     of one or two baddies picking a fight.
            // This exists as room-specific flavortext for when battle starts.  It is does not the handle actual battles.
            Console.WriteLine("Battle flavor text for this room has not yet been written");
        }
		public static void StairsLook()
		{
			Console.WriteLine("\nThe stairs lead to the upper levels of the hotel, where only gang members or people they deem worthy are allowed to dwell" +
			".  i.e. Not you.  The grand set of stairs swirl up to a balcony where you can see the occasional made-up woman or stern-eyed man stare down " +
			"at the floor below.  The two guards sitting on the bottom of the steps notice you staring and silently direct you to point your eyes elsewhere.");
		}
		public static void Irritated()
		{
			Console.WriteLine("\nThe two men do not respond to you.  One rolls his eyes, and the other looks at you disdainfully.  They don't look like " +
			"They want to converse with you.");
		}
		public static void AlmostPissed()
		{
			Console.WriteLine("\nBoth men stare at you this time.  One of them puts his hand on the revolver sticking out of his hoodie pocket.  Both stare " +
			"until you feel rather uncomfortable. \n\"Go trade or get out.\" one of the guys snaps at you.");
		}
		public static void PissedOff()
		{
			Console.WriteLine("\nThe two guards pull out their guns.  You draw your weapon, but even if you had a firearm, it wouldn't be very likely that " +
			"you could defeat these two guys.  Given that there's also thugs on the balcony above, you are barely able to wince before your remains " +
			"are donated to the stains and odors of that unfortunate carpet.  \n\"Man, what a waste of bullets.\" is the last thing that you hear.");
		}
		public static void LookCarpet()
		{
			Console.WriteLine("\nProbably the carpet at one point was worth looking at.  Some fancy, perhaps Victorian pattern runs through its fibers.  "+
			"It may once have been a royal red and dignified orange, but now it looks like the way this whole place smells.");
		}
		public static void LookPlant()
		{
			Console.WriteLine("\nIt's just a plant.  And also an ashtray, to judge by the cigarette butts that cover the pot of soil underneath like " +
			"like an overly enthusiastic graveyard.  As you absentmindedly touch the long, leathery fronds, something brushes against your hand.");
		}
		public static void LookPlantA()
		{
			Console.WriteLine("What's this?  Someone has taped a couple of cigarettes to the bottom of a leaf.  You quietly abscond them and stick them " +
			"in a pocket.");
		}
		public static void LookPlantB()
		{
			Console.WriteLine("\nYou check again, but there are no more cigarettes under the plant's leaves.  Too bad.");
		}
		public static void GoUpstairs()
		{
			Console.WriteLine("\nOkay, fine, don't take my advice.  You confidently stride toward the stairs, nodding confidently at the two guards.  " +
			"They seem briefly confused, but before you can pass them by, they grab you by the arms and ask you who you are in rather violent terms, " +
			"filled with all their favorite expletives.  Now, honestly, I could go into a big spiel about how you get dragged upstairs, forcibly interrogated, " +
			"then tortured until your torturers run out of creative ways to amuse themselves upon you, and thereafter killed, but quite frankly "+
			"it's getting late, and I'd like to read my history book before I go to sleep.  Goodnight yourself.  Forever.");
		}





        //
        //
        //
        // This is supposed to be the hotel ballroom and shop, but I ran out of time.  I'm sorry.
        public static void HotelBallroomLook()
        {
            Console.WriteLine("\nYou enter the old ballroom.  In here the smell of farts gives way to the reign of tobacco, and a few people gather at the " +
                "stained remains of perhaps once elegant furniture.  The long table at the far side of the room is of no interest to you, as the people who sit " +
                "around it trade in goods too rich for your blood, like fresh bread and wristwatches.  A couple of guys sit in fancy chairs, yet work with dirty " +
                "books of paper on crates.  paper on crates.  One of them, a man in a blue cap, eyes you with a pleasant air, as one would silently greet " +
                "a potential customer.");
        }
        public static void TalkBlueHat()
        {
            Console.WriteLine("You approach the man and start to speak, but he cuts you off." +
                "\n\t\"Sorry, man.  We were supposed to be a shop, but the Programmers ran out of time.\" the man shrugs.  \"Can't do nothin' for you.  Sorry.\"");
        }





        //
        //
        //
        //  These are the commands associated with attempting to go outside of the game's boundaries.  They can be linked with any relevant outside room.
        public static void OverDebris()
        {
            Console.WriteLine("\nFor some reason, it possesses you to try and climb over the pile of ruin that blocks the way out of the this place.  " +
                "The torn concrete, broken cars, and various assorted detritus provide a climbable, if dangerous, way up.  You claw your way up, tearing " +
                "your pants on a bit of metal from an old windshield and scraping your arm against a rusted metal bar.  The downside is just as dangerous, and " +
                "on the way down a brick tumbles out from underneath your feet.  You slip, banging your chin against more brick, but manage to keep holding on.  " +
                "You're concentrating so hard that you don't at first notice the yelling at your back.  It is, however, much harder to ignore the bullet that " +
                "slips through your gut.  You still cling to the rubble, but the bullet, unfortunately, brought a few of its friends along.  You never find out if " +
                "it was the Mange or one of their enemies that shot you. ");
        }
        public static void CrossStreetWarning()
        {
            Console.WriteLine("\nDude, you really don't want to do that.  This street is open for the purposes of bringing in supplies to the Mange.  And to " +
                "a lesser extent, everyone else.  However, that means it's guarded like crazy, and people who aren't Mange members don't get to leave.  Seriously, " +
                "don't go that way.");
        }
        public static void CrossStreet()
        {
            Console.WriteLine("\nDespite the fact you know that it's a terrible idea, you start to walk across the street.  For several seconds, nothing happens.  " +
                "It dawns on you exactly how bad of an idea that this is when a truck pulls up, filled with Mange gang members.  A couple of them point their firearms " +
                "at you -- remember, border patrol -- but thankfully a couple of them recognize you.  They're about to ask why you're there (presumably so that they can " +
                "save bullets by scaring you back into their territory), when the roar of an engine sounds behind you.  You turn to see another car, armored with random " +
                "bits of metal.  The unarmored bits are windows, and sport several violent-looking people with firearms.  Not Mange, as you can tell by the bullets " +
                "flying overhead.  The other car returns the Mange's fire, and guess who's caught in the middle?  You have no idea who is responsible for your death, " +
                "but does it really matter?");
        }







        //  Map Z1
        //
        //  Just outside the animal hospital that is the boss room
        public static void MapZ1Look()
        {
            Console.WriteLine("\nYou are just north of the old hotel.  To the north is a street you can cross...technically.  On the other side of the north " +
                "street is the headquarters of the Mange.  According to the words on the decrepit building, it used to be an animal hospital.  Half the building has " +
                "been blocked off with various rubbish, but you could still enter, if you wanted to.  To the east is another part of the safe area of the Mange's " +
                "territory.  To the west is a more or less impassible wall of debris, still up from the war.  To the southwest is an alleyway between the rubble wall " +
                "and the hotel. Besides that, you are standing on open sidewalk.");
        }
        public static void LookAtHosp()
        {
            Console.WriteLine("\nThe animal hospital is a brick building, huge and imposing.  You figure that the Mange must have first set up shop there because it " +
                "was a good place to score medical supplies.  Of course, that was over ten years ago, so probably not much is left of its original stock.  The building " +
                "doesn't look heavily guarded, but it's a reasonable assumption that there are guards out of sight.  The grey double doors are probably not locked, " +
                "but the patch of cement in front of the door is still stained from the last guy that tried to get in uninvited.");
        }

        public static void LookAtHotelFromBack()
        {
            Console.WriteLine("\nThere isn't much to see here.  The windows on this side of the hotel have long since been barred or boarded.  Though you can still " +
                "hear a bit of noise coming from inside the hotel.  Someone arguing about a price, you think.");
        }
        public static void HospitalWarning()
        {
            Console.WriteLine("\nUh, are you sure about that?  The animal hospital across the street is the headquarters of the Mange.  You shouldn't go there" +
                "unless you're sure you're ready.");
        }






        // Map Z2
        //
        // Center top of map, remains of Tama Cafe
        public static void MapZ2Look()
        {
            Console.WriteLine("\nNobody uses the street below your feet anymore.  Probably has something to do with the massive crater between it and the remains " +
                "of an old building.  A sign bearing \"Tama Cafe\" still stands proudly above the rubble, but the building itself is a pile of concrete, stripped " +
                "of whatever might have been of value when mortar fire permanently planted two co-centric craters in the ground below.  The broken street runs " +
                "south, between the old hotel and bank.  North was made impassable by the remains of a failed blockade of wrecked cars, but you can go west, and east.");
        }
        public static void LookAtHotelFromCafe()
        {
            Console.WriteLine("\nYou can kind of see the hotel from here, but mostly just the corner, as it's to the southwest.  This isn't the best angle to view the " +
                "hotel from.");
        }
        public static void LookAtBankFromCafe()
        {
            Console.WriteLine("\nFrom here the bank is just a corner.  If you went south, you could see it better.  From here, all you see is the back wall and the " +
                "mural of little alien dragonflies wearing large gold necklaces painted on the wall.");
        }
        public static void LookMural()
        {
            Console.WriteLine("\nThe mural is of semi-abstract alien beings, almost robotic, wearing lots of bling-bling and baggy clothing.  They appear to be cruising " +
                "around in a truck.  Judging by the level of dirt and wear on the mural, it's been a while since it was painted.");
        }





        // Map Z3
        //
        // Top right corner of map, old playground.
        public static void MapZ3Look()
        {
            Console.WriteLine("\nYou're standing in the remains of an old playground.  A teeter totter lies broken in half, a merry-go-round looks more like a " +
                "merry-go-rust, and an old swingset only has two remaining swings left.  To the north is still the wall of broken cars, and to the south is another " +
                "stretch of wall belonging to the old bank.  To the east is a tempting stretch of open road, but you know better than to go that direction.  It " +
                "represents the end of the Mange's territory, and is a usual dropping off spot for supplies.  Or it would be if they weren't fighting whoever " +
                "they're fighting.");
        }
        public static void LookMerryRound()
        {
            Console.WriteLine("\nThe merry-go-round is old and creaky.  It looks mostly intact, though.  You give the thing a casual spin, but at the shriek of the old" +
                "metal, you grab it and make it stop.");
        }
        public static void LookTeeterTotter()
        {
            Console.WriteLine("\nThere's no playing on this old thing.  It's broken halfway through, despite being made of metal.  It still bears colorful paint, and " +
                "the seats on each end look like little silver saddles.  It's sad, really.");
        }
        public static void LookBankWall()
        {
            Console.WriteLine("\nAll you see of the bank is the back wall, covered in its signature mural.");
        }
        public static void LookSwings()
        {
            Console.WriteLine("\nThe swings look like swings.  They're connected by chains, and have rubber seats.  Two of the four swings remain.  One of them looks " +
                "kind of loose.");
        }
        public static void LookSwingsTwo()
        {
            Console.WriteLine("\nThe swings look like swings.  They're connected by chains, and have rubber seats.  Well, the last one standing does.  Since you removed " +
                "half of the support from it, it hangs limply by the one chain it has left.");
        }
        public static void LookLooseSwing()
        {
            Console.WriteLine("\nThe upper bit of one chain on this swing seems to have a loose loop where it meets the frame of the swingset.  The connector piece isn't " +
                "soldered shut.  It looks like you could take the chain, assuming that the battered rubber of the swing is damaged enough.");
        }
        public static void LookLooseTwo()
        {
            Console.WriteLine("\nWell, the swing is loose now.  That'll happen when you take one of the chains off of it.");
        }
        public static void TakeChain()
        {
            Console.WriteLine("\nWith a bit of wriggling, you manage to snake the chain out from the connector loop.  The seat is almost as weak as it looks, but " +
                "it does take you a bit of time to pull the chain out from the weather-weary rubber. You keep the chain, leaving the now tattered rubber to hang " +
                "limp by one solitary chain.");
        }
        public static void TakeChainTwo()
        {
            Console.WriteLine("\nNah, you already have a chain.  Anyway, the rest of it looks too hard to get off without tools.");
        }
        public static void Play()
        {
            Console.WriteLine("\nLook, you don't have time to play right now.");
        }






        // Map Z5
        //
        // The far center left of the map, alley behind the hotel.

        public static void MapZ5Look()
        {
            Console.WriteLine("\nYou stand now in a narrow alley, with openings to the north and south.  To the west is that giant pile of debris that serves as " +
                "the border to the Mange's territory.  To the east, is the giant wall that is the back of the hotel.  In between is dirt, grime, and you.");
        }
        public static void LookHotelWall()
        {
            Console.WriteLine("\nThere isn't much to see here.  The lower windows are all boarded up.  The upper windows aren't, but since you know that only " +
                "Mange members ever go up there, you figure that any attempt to spy on them would be a bad idea.");
        }
        public static void SearchDebris()
        {
            Console.WriteLine("\nYou search the debris for anything useful.  Given that it's near impossible to see much without moving the hunks of concrete, " +
                "brick, and other heavy and sharp randomness, you decide further search is not warranted.");
        }





        // Map Z6
        //
        // The exact center of the map, area between the hotel and the bank.

        public static void MapZ6Look()
        {
            Console.WriteLine("\nThis is basically the center of the Mange's territory.  To the west is the hotel, what passes for a center of commerce in this " +
                "place.  To the east is the old bank, which used to be a shooting range for the Mange, before the bullet shortages began.  The road you're one stretches " +
                "both to the north and to the south.");
        }
        public static void LookHotelFront()
        {
            Console.WriteLine("\nThe hotel, despite being run down and mostly boarded up, still has enough of a sign to read \"Sheraton\".  You have no idea what that " +
                "means.  Because this is also a well-known Mange hangout, you can really only associate that word with a sense of dread.");
        }
        public static void LookBankFront()
        {
            Console.WriteLine("\nThe bank is even more run down than the hotel.  It also sports a name -- \"Sun Trust\"-- and it also sports a long line of bullet holes, " +
                "from top to bottom.  Pleasant.  Also, what kind of name for a bank is \"Sun Trust\"?  How does one not trust the sun?  We rely on it all the time, " +
                "regardless of how we feel about it.  So even if the sun goes all red star on us and burns us to a crisp, there's nothing we can do about it.  " +
                "\n\tYou take a brief moment to thank God for the book on astronomy you randomly found those years ago.  There's nothing like coping with modern " +
                "life by means of the void of space.");
        }








        // Map Z7
        //
        // Above bakery, below hotel, left side of map

        public static void MapZ7Look()
        {
            Console.WriteLine("\nYou stand in an alleyway between the bakery to your south and the hotel to your north.  It's pretty dirty out here, and this is the " +
                "one place where you have seen a dumpster.  For some reason, people still use it for trash, despite the fact that there hasn't been a garbage pickup " +
                "in ten years, or probably longer.  To the northwest is an alleyway, sliding up alongside the back of the hotel.  The west is blocked off by debris, " +
                "but the east is open and clear.  You can see an old pizzaria in that direction.");
        }
        public static void LookDumpster()
        {
            Console.WriteLine("\nThe dumpster is full of random stuff.  Dirty clothes, mainly.  You might think that people would hang on to any fabric they can in " +
                "this kind of world, but judging from the smell wafting from the very stained shirts and shorts, you're thinking that maybe whoever got rid of them " +
                "had the right idea.");
        }
        public static void SearchDumpster()
        {
            Console.WriteLine("\nReally?  You want to do that?  ...Okay.  You kick away the random junk to provide yourself with a safe pathway to the dumpster.  Then " +
                "you reach inside, gingerly using an old bag to pluck away the old clothes so that you don't actually have to touch them.  It all smells like ten years " +
                "of roadkill and dog crap, and that's putting it mildly.  You hold your breath and shudder in distaste.  After several extremely unpleasant hours " +
                "(seconds), you happen to pull away a strategic pair of jeans from the side of the dumpster.  There, in the little hollow on the side of the dumpster, " +
                "is a bit of open space where no trash is.  It looks like someone hid a mostly-full pack of cigarettes there.  \n\tA little message is scrawled into the " +
                "dumpster below: \"Take this and die, -Mange\"  \n\tGood.  You'd feel bad if you were taking from anyone but a gang member.  Oh look, a flashlight.  " +
                "You'll have that.");
        }
        public static void SearchDumpsterTwo()
        {
            Console.WriteLine("\nYou don't really have any desire to search the dumpster again.  You really don't want that smell attached to your person.");
        }
        public static void LookPizzariaFromAlley()
        {
            Console.WriteLine("\nThe pizzaria is kinda far from here.  You can't really see much of it besides the broken window out front and an old advertisement " +
                "on free breadsticks with a large pizza.  Technically you can't read that ad from here, but you've been there before, so you know what it says.");
        }
        public static void LookBakeryFromAlley()
        {
            Console.WriteLine("\nThe bakery wall, like many of the buildings in town, sports boarded up windows.  As you examine the building, you realize that " +
                "if you hadn't been told that this place used to be a bakery, then you would never have realized it.  Nothing about the exterior suggests " +
                "that it once sported fancy breads and cakes.  Kind of sad, really.");
        }
        public static void LookHotelFromAlley()
        {
            Console.WriteLine("\nThankfully, it's the hotel's wall that the dumpster is against.  Boarded windows line up against the wall.  Huh, there are lots of " +
                "boarded windows in this town.  You wonder where all the lumber came from.");
        }
        public static void RemoveBoards()
        {
            Console.WriteLine("\nAbsolutely not.  Removing boards from the Mange's hotel is just asking for trouble, and on the other side of the bakery's blocked windows " +
                "are the showers.  Showers which you happen to use, and prefer privacy when doing so.");
        }









        // Map Z9
        //
        // Large area between bakery and pizzaria

        public static void MapZ9Look()
        {
            Console.WriteLine("\nThis is a wide, open area, and the road that comes from the north ends in a wall of impassible rubble to the south.  To the west is the " +
                "former bakery where you live, and to the east is a former pizzaria, as evidenced by the sky-bleached blue adverts still hanging from its surprisingly " +
                "intact windows.  The odd thing about this area is that near the pizzaria, right there on the middle of the sidewalk, is a little square of ruined " +
                "concrete blocks.  It looks like the remains of a building, but is so small that it doesn't seem to serve much of a purpose.");
        }
        public static void LookBlocks()
        {
            Console.WriteLine("\nThe blocks are arranged in a square -- the last bit of their original configuration, you assume -- and also in a pile within that " +
                "square, as though the destroyer of this building, once finished with his work, carefully swept up all the rubble into a pile.");
        }
        public static void SearchBlocks()
        {
            Console.WriteLine("\nThe concrete blocks hide some pretty interesting things -- interesting, but useless.  You find the broken remains of a metal bowl, a " +
                "dirt-filled plastic bin that claims to have once held mayonnaise, and several small broken bits of plastic and wire.  The only clue to the clutter's " +
                "source is a bit of paper you dug out from between two blocks.  It's dirty, but is legible enough to read \"Jimmy Johns\".  You're not entirely certain " +
                "what that's supposed to mean.");
        }

        public static void LookBakeryFront()
        {
            Console.WriteLine("\nYou look at the bakery.  That is the place you have lived for the past ten years.  It is the place where you played as a child, learned " +
                "to read, and first learned how to hold a knife.  There are a lot of powerful memories from that old building, but none so powerful that they make you " +
                "want to stay in that old rectangle of bricks and sadness.");
        }
        public static void LookPizzariaFront()
        {
            Console.WriteLine("\nIt's a pizzaria, or was a generation ago.  You know what pizza is.  Even just looking up at the \"Gigi's Pizza\" sign brings back fond " +
                "memories of the time Uncle Greg found a can of tomato sauce, and then made some pizza out of a purloined back of corn flower, and spam for a topping.  " +
                "The advertisement in the window, besides displaying breadsticks, also mentions that pizzas normally come with cheese.  You've never told anyone this " +
                "before, but it's your biggest dream to have a pizza with cheese on it.  You've never had cheese before.\n\tYou don't really like thinking about what " +
                "happened to Uncle Greg, though.");
        }






        //
        //
        // Pizzaria
        public static void PizzariaLook()
        {
            Console.WriteLine("\nGigi's Pizza still looks kind of like a pizzaria.  This is one of the few buildings with minimal scrawling on the walls, more or " +
                "less intact windows, and strangest of all, the strokes of a brush mark the dust on the floor.  It's as if everyone silently agreed that the place " +
                "of pizza is the chapel of the day.  A few tables and chairs have survived the years, and the bar still has all but one of its stools still " +
                "rooted to the ground before it.  A jukebox in poor condition sits on the back wall to the south, and to the north is a bathroom.  Behind the bar is " +
                "a working kitchen.  At least, it smells like it's been used recently.");
        }
        public static void LookBathroom()
        {
            Console.WriteLine("\nThe bathroom is a unisex, single person bathroom.  And it smells.  Bad.  There's no toilet paper.  That's a commodity around these " +
                "parts.  That, and soap.  That, and running water.  Maybe the faucet works, but judging from the fact that this place isn't guarded around the clock, " +
                "you can guess that it's not holding the rare commodity that is water.");
        }
        public static void UseBathroom()
        {
            Console.WriteLine("\nYou really, really don't want to do that.  Someone got that idea before you, and the result is apparent anywhere within three feet of " +
                "the bathroom door.");
        }
        public static void LookKitchen()
        {
            Console.WriteLine("\nThe kitchen isn't much.  The oven, long since stained by years of disuse, hangs open without a door. There's nothing in the cabinets, " +
                "and the fridge has been long since emptied, but the fortunate thing about a pizza place is that the brick oven still works, even without electricity.  " +
                "There's even a bit of coal piled up next to it, along with some paper, sticks, and other flammable stuff.");
        }
        public static void UseKitchen()
        {
            Console.WriteLine("\nThere's no point in heating up food for later, because you don't want to carry hot cans, but if you eat anything here, the stove is " +
                "available for cooking.");
        }
        public static void TakeCoal()
        {
            Console.WriteLine("\nYou feel too uncomfortable to take the coal.  After all, someone was nice enough to bring it, and might not actually belong to the " +
                "Mange.  Besides, where else are you going to use the charcoal?");
        }
        public static void LookTables()
        {
            Console.WriteLine("\nThe chairs and tables are kinda dingy, but they are relatively intact.  The surfaces of the table probably aren't all that sanitary, " +
                "but they are free from dirt and detritus.  Same for the chairs.");
        }
        public static void SitDown()
        {
            Console.WriteLine("\nYou sit for a bit in a chair and rest your feet.  Only for a bit, as there's nothing for you to do here, and the chair wobbles.");
        }
        public static void LookJukebox()
        {
            Console.WriteLine("\nThe jukebox's glass front has been smashed, and no lights shine.  The records inside, however, are still intact.  A place lower down, " +
                "the coinhold for the jukebox, is open, and for some reason a note beside it reads, \"Leave the coins here\".  Huh.");
        }
        public static void LookCoins()
        {
            Console.WriteLine("\nYou glance in the coin storage of the jukebox and see a few quarters there.");
        }
        public static void TakeCoins()
        {
            Console.WriteLine("\nNah, people don't use money for stuff anymore.  It's got no value.");
        }
        public static void UseJukebox()
        {
            Console.WriteLine("\nYou take one of the coins from the coinhold and slip it into the jukebox's slot.  You glance at the names on the little paper " +
                "slips.  You've never heard of Frank Sinatra, but eh, he seems to have the most songs on here.  Reba MacIntyre used to be your favorite, but " +
                "not since...well, you still miss Uncle Greg.  Frank Sinatra comes with fewer memories of that sort.  You push the buttons, and the little metal " +
                "arm of the jukebox pulls out one of the records.  Sinatra's pleasant voice soon fills the old pizzaria.  Oh good, the jukebox still works.");
        }







        //
        //
        //  Boss Room, Animal Control
        public static void BossEntrance()
        {
            Console.WriteLine("\nYou enter the old animal hospital.  It's surprisingly clean on the inside, and the floor isn't covered in the dust you're " +
                "used to seeing in basically every building.  There's even a working light in the ceiling.  Guards sit up from chairs along the perimeter " +
                "of the room, too surprised at your daring entrance to be much upset at your entry.  For now.  They stare at you from stale eyes. " +
                "\n\tFrom the back of the room, sitting at a table, comes the likewise dull gaze of Connor Gunner, head honcho around these parts.  He stares " +
                "at you with a cup of something clear halfway to his mouth, and his silence asks the questions that his words don't need to say." +
                "\n\t\"Hello,\" you say with a polite nod.  \"If it's all the same to you, I'd like to leave.\"" +
                "\n\t\"Leave what?  Our turf?\" Gunner replies." +
                "\n\t\"Well, yeah.  I'd like to do so peacefully.\"" +
                "\n\t\"What if it doesn't happen peacefully?\"" +
                "\n\t\"Well then,\" you carefully grip your weapon.  \"It'll happen not so peacefully.  But let's be civil.  There's no need for anyone to get hurt\"" +
                "\n\tFor a moment, Gunner turns away.  He shakes his head with a smile, takes a drink, and then replaces the glass on its spot on a nearby table.  " +
                "He rises up from his chair and faces you, with an expression almost like a sense of pride.  Still, he must be a psychic, as without words his guards " +
                "surround him, weapons raised.  You do the same.");

        }

        public static void BossWonText()
        {
            Console.WriteLine("\nYou stand over Gunner's fallen form.  He's still alive, mainly because you know better than to destabilize local \"politics\" by " +
                "offing one of the few actual leaders in this town.  You kneel over him, watching as he wipes a bit of blood from his nose with his shirt.  " +
                "\n\t\"I really meant what I said about not causing trouble,\" you say.  \"I'm going to take whatever firearms are available, and then I'm going " +
                "to leave.  But before I do, I want you to tell me one thing.  What's going on on the outside?  Why are we all living like this?\"" +
                "\n\tGunner coughs before he answers.  \"It's the army.  Like, the real army.  They've recruited enough of the rival gangs out there to start " +
                "making something out of all the anarchy.  Something about making a brand new country out of the remnants of the old.\"" +
                "\n\t\"...And the Mange would rather 'stay independent', as it were.\"" +
                "\n\t\"You got it.  I ain't been running the Mange for the past decade just to hand it over to some random idealists.  And that's assuming that they " +
                "really are idealists.  Maybe they're just the same ol' with a new face.\" Gunner coughs again. \"Hey, " +
                "why don't you check out the other room over there.  If you're so ready to face the world that's out there, go ahead and take for yourself the 9mm " +
                "over there on the counter.  There's not much in the way of ammo, but fine, take it.\"" +
                "\n\tYou get back to your feet, but with one last look at him, you sneer \"And you were so willing to try and hang on to your precious little kingdom " +
                "that you would rather us all die than surrender to the real world?\"" +
                "\n\t\"Kid, this world's more complicated than that.  As soon as you walk out that back door, you're gonna find out.\"" +
                "\n\tYou have nothing more to say to Gunner.  You proceed to the next room over, to the right, and indeed find a handgun on the counter.  There " +
                "appear to be other firearms lying around as well, but to judge from the disassembly and the cleaning rags, they're in the process of cleaning.  Or " +
                "were.  You snag the intact handgun, root around for some bullets, and head for the rear of the animal hospital.  Ah, an old army helmet.  You'll " +
                "have that.");
        }

        public static void BossLoseText()
        {
            Console.WriteLine("\nYou lie on the floor, waiting for the final blow to end the suffering of your bruised body.  Gunner stands over you.  He picks " +
                "through your pockets, fishing out one last cigarette from your stained jacket.  As you lie there, breathing hard, he lights the cig and blows " +
                "a few puffs over you.  After a moment, he steps away.  Your vision starts to fade before he comes back.  You hear a click." +
                "\n\t\"I'm impressed enough,\" Connor says.  \"to waste a bullet on you.\"" +
                "\n\tYour suffering ends not long after.");
        }
        
    }
}
