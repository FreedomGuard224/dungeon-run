﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CityLibrary;

namespace CitySurvival
{
    class Program
    {
        static void Main(string[] args)
        {
            bool program = true;
            string status = "playing";
            int room = 1;
            

            string playerName;
            Console.WriteLine("Enter your name, Stranger");
            playerName = Console.ReadLine();
            //List<string> player = new List<string>();

            //Name, HP, Weapon, Weapon Damage
            //player[0] = playerName;
            //player[1] = "25";
            //player[2] = "Fist";
            //player[3] = "3";

            //create player object
            CityLibrary.Player player = new CityLibrary.Player(playerName);

            Console.WriteLine($"Hello, {player.Name}.");
            Console.WriteLine("You wake up, as you do, in the old, rundown bakery that has been your home for " +
                "the past eighteen months.  Well, yours and about a half dozen other people.  This whole block has" +
                "been the bastion of a gang called \'the Mange\', and for the time being they're not letting anyone" +
                "out.  They haven't said why, but the gunfire on the outside of their little locality makes it pretty" +
                "obvious that they don't consider it safe.  You'd almost think that Mange is concerned for the welfare" +
                "of the locals, except for the fact that you don't know who they're opposing, or even if this" +
                "opposition has weaponry of their own.  The Mange might be fighting them off to keep them from " +
                "getting local supplies.");
            Console.WriteLine("As much as this concerns you, the fact is whatever lies outside is a mystery.  What's " +
                "crystal clear is the fact that the Mange are extremely dangerous, and if traffic with the outside" +
                "doesn't resume, you'll all starve.  You don't plan on being one of those people.");
            Console.ReadLine();

            Console.WriteLine("You stretch against the stiffness in your bones and rise from the pile of rubbish that constitutes" +
                "your bed.  It's a big pile of rubbish, so it's also the bed of five other stragglers, three of which are still " +
                "resting there.");
            Console.WriteLine("\'Okay,\' you tell yourself.  \'Let's get to business\'.");


            while (program)
            {
                if (room == 1)
                {
                    Rooms.Bakery(ref player, ref room);
                }
                else if (room == 2)
                {
                    Rooms.BankLobby(ref player, ref room);
                }
                else if (room == 3)
                {
                    Rooms.BankOffice(ref player, ref room);
                }
                else if (room == 4)
                {
                    Rooms.BankVault(ref player, ref room);
                }
                else if (room == 5)
                {
                    Rooms.HotelLobby(ref player, ref room);
                }
                else if(room == 6)
                {
                    Rooms.HotelBallroom(ref player, ref room);
                }
                else if (room == 7)
                {
                    Rooms.HotelStairwell(ref player, ref room);
                }

                // Room outside of Animal Hospital, top left of map
                else if (room == 8)
                {
                    Rooms.Outside1(ref player, ref room);
                }

                // Area with ruined remains of cafe, top center of map
                else if(room == 9)
                {
                    Rooms.Outside2(ref player, ref room);
                }

                // Area east of cafe remains, top right of map
                else if (room == 10)
                {
                    Rooms.Outside3(ref player, ref room);
                }

                // Upper alley behind hotel, left side of map
                else if (room == 11)
                {
                    Rooms.Outside4(ref player, ref room);
                }

                // Lower alley behind hotel, left side of map
                else if (room == 12)
                {
                    Rooms.Outside5(ref player, ref room);
                }

                // Road between hotel and bar, center of map
                else if (room == 13)
                {
                    Rooms.Outside6(ref player, ref room);
                }

                // Area above old bakery, left side of map
                else if (room == 14)
                {
                    Rooms.Outside7(ref player, ref room);
                }

                // Alley behind old bakery, bottom left corner of map
                else if (room == 15)
                {
                    Rooms.Outside8(ref player, ref room);
                }

                // Large area east of bakery, bottom center of map
                else if (room == 16)
                {
                    Rooms.Outside9(ref player, ref room);
                }

                // Large area further east of bakery, in front of pizzaria, bottom center of map
                else if (room == 17)
                {
                    Rooms.Outside10(ref player, ref room);
                }

                // Alley just below the pizzaria, bottom right corner of map
                else if (room == 18)
                {
                    Rooms.Outside11(ref player, ref room);
                }

                else if (room == 19)
                {
                    Rooms.Pizzaria(ref player, ref room);
                }
                else if (room == 20)
                {
                    Rooms.PizzariaOffice(ref player, ref room);
                }
                else if (room == 21)
                {
                    Rooms.AnimalControl1(ref player, ref room);
                }
                else if (room == 22)
                {
                    Rooms.AnimalControl2(ref player, ref room);
                }
                else
                {
                    status = "lost";
                }
            }

            // Winning and losing conditions go here
            if (status== "won")
            {

            }
            else if (status == "lost")
            {

            }
        }
    }
}
