﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CityLibrary;

namespace CitySurvival
{
    public class Text
    {
        //
        // Utility  or battle functions for player, should be available for all rooms. 
        //
        //
        public static void LookInventory(Player player)
        {
            Console.Write("Here is your inventory:  ");
            for (int i = 0; i<player.Inventory.Count; i++)
            {
                if (i == player.Inventory.Count - 1)
                {
                    Console.Write($"{player.Inventory[i]}.\n");
                }
                else
                {
                    Console.Write($"{player.Inventory[i]}, ");
                }
            }
        }
        
        public static void Help()
        {
            Console.WriteLine("\n Help Text -- ");
            Console.WriteLine("The listed options for a given room are not the only actions you can take.  You can \'look\' and \'search\' all important" +
                "items or areas.  Capitalization does not matter.  ");
            // This is all I could think of for now, adding more help text when issues pop up.
        }

        // Battle program for generic battles.
        public static Player BattleTime(Player player)
        {
            return player;
        }







        //
        //
        // Room specific text goes below here.
        //
        //




        //
        //
        // The bakery
        public static void BakeryLook()
        {
            Console.WriteLine("\nYou are in the remains of what was once an old bakery.  Against the south wall is a large pile of soft-ish rubbish, " +
                "mainly meant for sleeping.  To the west are a few cabinets, generally only containing things not worth stealing.  Exit doors fit " +
                "into the north and east walls.  In the northeast corner is a makeshift shower made from a few old hoses and coffee cans.  ");
        }
        public static Player Cabinets(Player player)
        {
            Console.WriteLine("You search through the cabinets only casually.  It wouldn't do to look too eager to search through other people's " +
                "belongings.  Most of the cabinets still have doors, and those that don't are generally empty of all but greasy rags or other detritus.");

            // temporary item until items have been worked out
            if (player.Inventory.Contains("hammer"))
            {
                Console.WriteLine("You search the cabinet that is more or less yours.  It's still got the old random junk in it.  No surprises.");
            }
            else
            {
                Console.WriteLine("One specific cabinet is more or less yours.  You've been putting random items in it so that the randos in here " +
                    "get used to the idea that it's yours.  Mainly you put in it random junk -- the arms of broken action figures, paperclips, broken " +
                    "pottery -- anything to suggest that you're some eclectic who likes things not worth owning.  You search through it, and find that " +
                    "one of the items actually is useful.");
                // insert item getting code here
                return player;
            }
            return player;
        }
        public static void Showers()
        {
            Console.WriteLine("You're not terribly shy about showering in front of the guys in the bakery -- as a rule, nobody stares -- but it's nice " +
                "to have shower curtains anyway.  Actual curtains, that is, strung about with some old fishing line.  You push past the fabric and check " +
                "behind the jerry-rigged shower.  Aw great, they didn't fill up the water tanks.  Lovely.  Good thing you checked before taking off your" +
                "clothes. ");
        }

        public static void Rubbish()
        {
            Console.WriteLine("You search through the pile of rags and tattered furniture bits that are not currently covered by the sleeping or " +
                "resting.  As you expect, there's nothing you need.");
        }
    }
}
