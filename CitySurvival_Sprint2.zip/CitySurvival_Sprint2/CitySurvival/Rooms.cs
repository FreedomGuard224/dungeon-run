﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CityLibrary;

namespace CitySurvival
{
    public class Rooms
    {
        public static Player Bakery(ref Player player, ref int room)
        {
            bool getout = false;
            string action;

            while (!getout)
            {
                Console.WriteLine("\n");
                Text.BakeryLook();
                Console.WriteLine("- North.");
                Console.WriteLine("- East.");
                Console.WriteLine("- \n");

                action = Console.ReadLine();

                if (action.ToLower().Contains("take a shower") || action.ToLower().Contains("shower"))
                {
                    Text.Showers();
                }
                else if (action.ToLower().Contains("look cabinets") || action.ToLower().Contains("cabinets") || action.ToLower().Contains("search cabinets"))
                {
                    Text.Cabinets(player);
                }
                else if (action.ToLower().Contains("search rubbish") || action.ToLower().Contains("looks rubbish"))
                {
                    Text.Rubbish();
                }
                else if (action.ToLower().Contains("north"))
                {
                    Console.WriteLine("\nYou open the door and go north.");
                    room = 14;
                }
                else if (action.ToLower().Contains("east"))
                {
                    Console.WriteLine("\nYou walk east through the open door.");
                    room = 16;
                }
                /// Make sure to keep the look option near the bottom, in case one of the other commands also has a 'look' in it.
                else if (action.ToLower().Contains("Look"))
                {
                    Text.BakeryLook();
                }
                else if (action.ToLower().Contains("look inventory") || action.ToLower().Contains("inventory") || action.ToLower().Contains("look at inventory."))
                {
                    Text.LookInventory(player);
                }
                else if (action.ToLower().Contains("help"))
                {
                    Text.Help();
                }
                else
                {
                    Console.WriteLine("\nInput not understood.");
                }
            }

            return player;
        }





        public static Player BankLobby(ref Player player, ref int room)
        {

            return player;
        }
        public static Player BankOffice(ref Player player, ref int room)
        {

            return player;
        }
        public static Player BankVault(ref Player player, ref int room)
        {
            return player;
        }

        public static Player HotelLobby(ref Player player, ref int room)
        {
            return player;
        }

        public static Player HotelBallroom(ref Player player, ref int room)
        {
            return player;
        }
        public static Player HotelStairwell(ref Player player, ref int room)
        {
            return player;
        }

        public static Player Outside1(ref Player player, ref int room)
        {
            // In front of boss doors, top left
            return player;
        }

        public static Player Outside2(ref Player player, ref int room)
        {
            // ruins of old coffee shop, top center
            return player;
        }

        public static Player Outside3(ref Player player, ref int room)
        {
            // upper right corner of block, dangerous gangs, only left, down
            return player;
        }

        public static Player Outside4(ref Player player, ref int room)
        {
            // back alley behind hotel
            return player;
        }

        public static Player Outside5(ref Player player, ref int room)
        {
            // lower back alley behind hotel
            return player;
        }

        public static Player Outside6(ref Player player, ref int room)
        {
            // between the hotel and the bank
            return player;
        }

        public static Player Outside7(ref Player player, ref int room)
        {
            return player;
        }

        public static Player Outside8(ref Player player, ref int room)
        {
            return player;
        }

        public static Player Outside9(ref Player player, ref int room)
        {
            return player;
        }

        public static Player Outside10(ref Player player, ref int room)
        {
            return player;
        }

        public static Player Outside11(ref Player player, ref int room)
        {
            return player;
        }

        public static Player Pizzaria(ref Player player, ref int room)
        {
            return player;
        }

        public static Player PizzariaOffice(ref Player player, ref int room)
        {
            return player;
        }

        public static Player AnimalControl1(ref Player player, ref int room)
        {
            // Gang hangout
            return player;
        }

        public static Player AnimalControl2(ref Player player, ref int room)
        {
            // Big Boss Room
            return player;
        }

    }
}
