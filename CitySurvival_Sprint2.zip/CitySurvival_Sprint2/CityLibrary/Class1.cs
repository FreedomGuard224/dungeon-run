﻿using System;
using System.Collections.Generic;

namespace CityLibrary
{
    public class Player
    {
        // Name, HP, Weapon, ItemList
        private string _name;
        private int _hp;
        private string _weapon;
        public List<string> Inventory { get; set; }

        public Player()
        {
            Name = "Roger";
            HP = 25;
            Weapon = "Fist";
            Inventory = new List<string>();
        }

        public Player(string name)
        {
            Name = name;
            HP = 25;
            Weapon = "Fist";
            Inventory = new List<string>();
        }

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        public int HP
        {
            get { return _hp; }
            set { _hp = value; }
        }

        public string Weapon
        {
            get { return _weapon; }
            set { _weapon = value; }
        }

    }

    public class Thug
    {
        // Name, Type, HP, weapon
        private string _name;
        private string _gangtype;
        private int _hp;
        private string _weapon;

        public Thug()
        {
            Name = "Bob";
            GangType = "";
            HP = 0;
            Weapon = "";
        }

        public Thug(string name, string gangType, int hp, string weapon)
        {
            Name = name;
            GangType = gangType;
            HP = hp;
            Weapon = weapon;
        }

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        public string GangType
        {
            get { return _gangtype; }
            set { _gangtype = value; }
        }
        public int HP
        {
            get { return _hp; }
            set { _hp = value; }
        }

        public string Weapon
        {
            get { return _weapon; }
            set { _weapon = value; }
        }
    }

    public class Weapon
    {
        // Name, description, damage stat
        private string _name;
        private string _description;
        private int _damage;

        public Weapon()
        {
            Name = "Fist";
            Description = "Those things on the ends of your arms.";
            Damage = 3;
        }

        public Weapon(string name, string description, int damage)
        {
            Name = name;
            Description = description;
            Damage = damage;
        }

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        public string Description
        {
            get { return _description; }
            set { _description = value; }
        }
        public int Damage
        {
            get { return _damage; }
            set { _damage = value; }
        }

    }

    public class Potion
    {
        // Name, Description, Healthboost stat
        private string _name;
        private string _description;
        private int _boost;

        public Potion()
        {
            Name = "";
            Description = "";
            Boost = 0;
        }

        public Potion(string name, string description, int boost)
        {
            Name = name;
            Description = description;
            Boost = boost;
        }

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        public string Description
        {
            get { return _description; }
            set { _description = value; }
        }
        public int Boost
        {
            get { return _boost; }
            set { _boost = value; }
        }

    }


}
