﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/**
* 15 Sep 2019
* CSC 253
* Edmund Gonzales and Bethany Reagan
* City Survival 
*/

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            bool exit = false;

            do
            {
                Console.WriteLine("1) Run Program");
                Console.WriteLine("2) Exit");
                Console.Write("Pick an option: ");
                string option = Console.ReadLine();
                Console.WriteLine("");

                if (option == "1")
                {
                    Console.Write("Enter a phrase or cardinal direction: ");
                    string input = Console.ReadLine();

                    if (input == "rooms")
                    {
                        rooms();
                    }

                    else if (input == "weapons")
                    {
                        weapons();
                    }
                    else if (input == "potions")
                    {
                        potions();
                    }
                    else if (input == "treasures")
                    {
                        treasurs();
                    }
                    else if (input == "items")
                    {
                        items();
                    }
                    else if (input == "mobs")
                    {
                        mobs();
                    }
                    else if (input == "north") 
                    {
                        //still working on this area
                        rooms();
                    }
                }
                else if (option == "2")
                {
                    exit = true;
                }
                else
                {
                    Console.WriteLine("Not an option!");
                }
            } while (exit == false);
        }

        public static void rooms()
        {
            int size = 5;

            string[] rooms = new string[size];
            rooms[0] = "bakery";
            rooms[1] = "outside1";
            rooms[2] = "outside2";
            rooms[3] = "outside3";
            rooms[4] = "bossRoom"; 

            Console.WriteLine("");
            for (int count = 0; count < rooms.Length; count++)
            {
                Console.WriteLine(rooms[count]);
            }
            Console.WriteLine("");
        }
        public static void weapons()
        {
            int size = 4;

            string[] weapons = new string[size];
            weapons[0] = "slingShot";
            weapons[1] = "chain";
            weapons[2] = "oldPipe";
            weapons[3] = "bat"; 

            Console.WriteLine("");
            for (int count = 0; count < weapons.Length; count++)
            {
                Console.WriteLine(weapons[count]);
            }
            Console.WriteLine("");

        }
        public static void potions()
        {
            int size = 2;

            string[] potions = new string[size];
            potions[0] = "health";
            potions[1] = "energy";

            Console.WriteLine("");
            for (int count = 0; count < potions.Length; count++)
            {
                Console.WriteLine(potions[count]);
            }
            Console.WriteLine("");

        }
        public static void treasurs()
        {
            int size = 3;

            string[] treasures = new string[size];
            treasures[0] = "food";
            treasures[1] = "cigarettes";
            treasures[2] = "clothes";

            Console.WriteLine("");
            for (int count = 0; count < treasures.Length; count++)
            {
                Console.WriteLine(treasures[count]);
            }
            Console.WriteLine("");

        }
        public static void items()
        {
            List <string> items = new List <string> ();

            items.Add("key");
            items.Add("cup");
            items.Add("map");

            Console.WriteLine("");
            for (int count = 0; count < items.Count; count++)
            {
                Console.WriteLine(items[count]);                
            }
            Console.WriteLine("");

        }
        public static void mobs()
        {
            List<string> mobs = new List<string>();

            mobs.Add("hat gangster");
            mobs.Add("bandanna gangster");
            mobs.Add("biker");
            mobs.Add("punk");
            mobs.Add("boss");

            Console.WriteLine("");
            for (int count = 0; count < mobs.Count; count++)
            {
                Console.WriteLine(mobs[count]);
            }
            Console.WriteLine("");

        }
    }
}
